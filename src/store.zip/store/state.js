export default {
    state: {
        todos:[]
    }
}