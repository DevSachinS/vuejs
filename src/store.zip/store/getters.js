export const getTodos = (state) => {
    return state.todos;
}