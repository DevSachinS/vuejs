<template>
    <div class="register">
    <img src="../assets/logo.png"/>
  
     <input type="text" v-model="email" placeholder="Enter Email "/>
      <input type="password" v-model="password" placeholder="Enter Password"/>
      <button v-on:click="login" >Login</button>
      <p><router-link to="/signup">Signup</router-link></p>
</div>
</template>
<script>
import axios from 'axios'

export default {
  name:"LoginPage",
   data(){
     return{
         email:"",
         password:""
     }
 },
 methods:{
     async login(){
         let result= await axios.get(`http://localhost:3000/users?email=${this.email}&password=${this.password}`)
    
 
         if(result.status=="200" && result.data.length > 0){
             localStorage.setItem("user-info",JSON.stringify(result.data))
             this.$router.push({name:"HomePage"})
         }else{
             alert("Invalid Password")
         }
      }
 }
}
</script>
