<template>
<HeaderMenu/>
    <h3>Welcome To Update Resturant Page</h3>
</template>

<script>
import HeaderMenu from "./Header.vue"
export default {
  name:"UpdatePage",
  components:{
      HeaderMenu
  },
}
</script>