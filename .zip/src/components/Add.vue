<template>
<HeaderMenu/>
    <h3>Welcome To Add Resturant Page</h3>
</template>

<script>
import HeaderMenu from "./Header.vue"
export default {
  name:"AddPage",
  components:{
      HeaderMenu
  },
}
</script>